#include "stdafx.h"
#include "Resource.h"
#include <mmsystem.h>
#include <ddraw.h>
#include "audio.h"
#include "gamelib.h"
#include "CEraser.h"
#include <math.h>

namespace game_framework {
	/////////////////////////////////////////////////////////////////////////////
	// CEraser: Eraser class
	/////////////////////////////////////////////////////////////////////////////

	CEraser::CEraser()
	{
		Initialize();
	}

	int CEraser::GetX1()
	{
		return x;
	}

	int CEraser::GetY1()
	{
		return y;
	}

	int CEraser::GetX2()
	{
		return x + working_right.Width();
	}

	int CEraser::GetY2()
	{
		return y + working_right.Height();
	}

	void CEraser::Initialize()
	{
		const int X_POS = 280;
		const int Y_POS = 300;
		x = X_POS;
		y = Y_POS;
		isMovingLeft = isMovingRight = isMovingUp = isMovingDown = false;
	}

	void CEraser::LoadBitmap()
	{
		working_right.AddBitmap(IDB_ManRight1, RGB(255, 255, 255));
		working_right.AddBitmap(IDB_ManRight2, RGB(255, 255, 255));
		working_left.AddBitmap(IDB_ManLeft1, RGB(255, 255, 255));
		working_left.AddBitmap(IDB_ManLeft2, RGB(255, 255, 255));
		leg_right.AddBitmap(IDB_LegRight1, RGB(255, 255, 255));
		leg_right.AddBitmap(IDB_LegRight2, RGB(255, 255, 255));
		leg_right.AddBitmap(IDB_LegRight3, RGB(255, 255, 255));
		leg_right.AddBitmap(IDB_LegRight4, RGB(255, 255, 255));
		leg_right.AddBitmap(IDB_LegRight5, RGB(255, 255, 255));
		leg_left.AddBitmap(IDB_LegLeft1, RGB(255, 255, 255));
		leg_left.AddBitmap(IDB_LegLeft2, RGB(255, 255, 255));
		leg_left.AddBitmap(IDB_LegLeft3, RGB(255, 255, 255));
		leg_left.AddBitmap(IDB_LegLeft4, RGB(255, 255, 255));
		leg_left.AddBitmap(IDB_LegLeft5, RGB(255, 255, 255));
	}
	void CEraser::OnMove()
	{
		const int STEP_SIZE = 2;
		//animation.OnMove();
		if (isMovingLeft) {
			x -= STEP_SIZE;
			working_left.OnMove();
			leg_left.OnMove();
			workingState = false;
		}
		if (isMovingRight) {
			x += STEP_SIZE;
			working_right.OnMove();
			leg_right.OnMove();
			workingState = true;
		}
		if (isMovingUp) {
			//y -= STEP_SIZE;
			/*for (int i = 0; i <= 3; i++) {
				y = y - (int(sin(i) * 10) + STEP_SIZE);
			}
			for (int i = 3; i >= 0; i--) {
				y = y + (int(sin(i) * 10) + STEP_SIZE);
			}*/
			jumpState = true;
		}
		if (isMovingDown)
			y += STEP_SIZE;
	}

	void CEraser::SetMovingDown(bool flag)
	{
		isMovingDown = flag;
	}

	void CEraser::SetMovingLeft(bool flag)
	{
		isMovingLeft = flag;
	}

	void CEraser::SetMovingRight(bool flag)
	{
		isMovingRight = flag;
	}

	void CEraser::SetMovingUp(bool flag)
	{
		isMovingUp = flag;
	}

	void CEraser::SetXY(int nx, int ny)
	{
		x = nx; y = ny;
	}

	void CEraser::OnShow()
	{
		int v = 0;
		const int STEP_SIZE = 2;
		if (jumpState) {			//���D
			cTa += 3;
			if (workingState) {
				leg_right.SetTopLeft(x + 11, (y + 53)- int(sin(cTa) * 100));
				leg_right.OnShow();
				working_right.SetTopLeft(x , y - int(sin(cTa) * 100));
				working_right.OnShow();
			}
			else {
				leg_left.SetTopLeft(x , (y + 53) - int(sin(cTa) * 100));
				leg_left.OnShow();
				working_left.SetTopLeft(x , y - int(sin(cTa) * 100));
				working_left.OnShow();
			}
			if (cTa >= 80) {			//�������D
				jumpState = false;
				cTa = 10;
			}
		}
		else {
			if (workingState) {
				leg_right.SetTopLeft(x + 11, y + 53);
				leg_right.OnShow();
				working_right.SetTopLeft(x, y);
				working_right.OnShow();
			}
			else {
				leg_left.SetTopLeft(x + 11, y + 53);
				leg_left.OnShow();
				working_left.SetTopLeft(x, y);
				working_left.OnShow();
			}
			if (isMovingLeft) {
				leg_left.SetTopLeft(x + 11, y + 53);
				leg_left.OnShow();
				working_left.SetTopLeft(x, y);
				working_left.OnShow();
			}
			if (isMovingRight) {
				leg_right.SetTopLeft(x + 11, y + 53);
				leg_right.OnShow();
				working_right.SetTopLeft(x, y);
				working_right.OnShow();
			}
		}
		
	}

}